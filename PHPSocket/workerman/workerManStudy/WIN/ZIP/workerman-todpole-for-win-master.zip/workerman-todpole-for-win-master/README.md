# workerman-todpole-for-win
小蝌蚪windows版本

安装
=====
无需安装，只要php环境ok即可运行。

要求 php>=5.3.3 并且配置好了php环境变量

windows系统php环境配置参考 http://www.workerman.net/windows
  
启动停止
=====
启动

双击start_for_win.bat

停止

ctrl+c 停止

注意：  
=======
windows系统下无法使用 stop reload status 等命令  

测试
=======
浏览器访问 http://服务器ip或域:55151,例如http://127.0.0.1:8383

 [更多请访问www.workerman.net](http://www.workerman.net/)
